#!/bin/bash
#SBATCH --job-name=JOB8
#SBATCH --time=168:00:00
#SBATCH --cpus-per-task=2
#SBATCH --mem=8000
#SBATCH --partition=regular

cd
module purge
module load Python/3.6.4-foss-2018a

source tf/bin/activate

cd Wildfire-Control-Python
make

python main.py -r -m 0 -e 10000 -t DQN -n DQN6
python main.py -r -m 0 -e 10000 -t DQN -n DQN7
python main.py -r -m 0 -e 10000 -t DQN -n DQN8
python main.py -r -m 0 -e 10000 -t DQN -n DQN9
python main.py -r -m 0 -e 10000 -t DQN -n DQN10