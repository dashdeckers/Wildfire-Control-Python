#!/bin/bash
#SBATCH --job-name=JOB15
#SBATCH --time=168:00:00
#SBATCH --cpus-per-task=2
#SBATCH --mem=8000
#SBATCH --partition=regular

cd
module purge
module load Python/3.6.4-foss-2018a

source tf/bin/activate

cd Wildfire-Control-Python
make

python main.py -r -m 100 -e 10000 -t DDQN -n DDQN1
python main.py -r -m 100 -e 10000 -t DDQN -n DDQN2
python main.py -r -m 100 -e 10000 -t DDQN -n DDQN3
python main.py -r -m 100 -e 10000 -t DDQN -n DDQN4
python main.py -r -m 100 -e 10000 -t DDQN -n DDQN5