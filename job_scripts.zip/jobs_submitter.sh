#!/bin/bash
# SARSA
sbatch job_script_1.sh
sbatch job_script_2.sh
sbatch job_script_3.sh
sbatch job_script_4.sh
sbatch job_script_5.sh
sbatch job_script_6.sh
# DQN
sbatch job_script_7.sh
sbatch job_script_8.sh
sbatch job_script_9.sh
sbatch job_script_10.sh
sbatch job_script_11.sh
sbatch job_script_12.sh
# DUEL DQN
sbatch job_script_13.sh
sbatch job_script_14.sh
sbatch job_script_15.sh
sbatch job_script_16.sh
sbatch job_script_17.sh
sbatch job_script_18.sh