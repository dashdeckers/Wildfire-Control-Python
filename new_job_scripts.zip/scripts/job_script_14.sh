#!/bin/bash
#SBATCH --job-name=JOB14
#SBATCH --time=71:59:00
#SBATCH --cpus-per-task=2
#SBATCH --mem=8000
#SBATCH --partition=regular

cd
module purge
module load Python/3.6.4-foss-2018a

source tf/bin/activate

cd Wildfire-Control-Python
make

python main.py -r -m 0 -e 10000 -t DDQN -n DDQN6
python main.py -r -m 0 -e 10000 -t DDQN -n DDQN7
python main.py -r -m 0 -e 10000 -t DDQN -n DDQN8
python main.py -r -m 0 -e 10000 -t DDQN -n DDQN9
python main.py -r -m 0 -e 10000 -t DDQN -n DDQN10